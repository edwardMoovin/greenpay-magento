<?php

namespace Greenpay\GreenpayPaymentGateway\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class GreenpayBitacora extends AbstractDb
{
    public function _construct()
    {
        $this->_init( 'greenpay_transactions', 'id' );
    }
}