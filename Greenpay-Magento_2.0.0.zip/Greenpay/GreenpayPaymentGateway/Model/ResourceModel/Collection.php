<?php

namespace Greenpay\GreenpayPaymentGateway\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    public function _construct() 
    {
        $this->_init( "Greenpay\GreenpayPaymentGateway\Model\GreenpayBitacora", "Greenpay\GreenpayPaymentGateway\Model\ResourceModel\GreenpayBitacora" );
    }
}