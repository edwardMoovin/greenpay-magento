<?php

namespace Greenpay\GreenpayPaymentGateway\Model;

use Magento\Framework\Model\AbstractModel;

class GreenpayBitacora extends AbstractModel
{
	public function _construct(){
		$this->_init( "Greenpay\GreenpayPaymentGateway\Model\ResourceModel\GreenpayBitacora" );
	}
}