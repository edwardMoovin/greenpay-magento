<?php
namespace Greenpay\GreenpayPaymentGateway\Model\Ui;

use Greenpay\GreenpayPaymentGateway\Gateway\Config\Config;
use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\Session\SessionManagerInterface;

/**
 * Class ConfigProvider
 */
class ConfigProvider implements ConfigProviderInterface
{
    const CODE = 'greenpay';
    const PUBLIC_KEY = 'public_key';
    const PUBLIC_KEY_SANDBOX = 'public_key_sandbox';
    const CC_VAULT_CODE = 'greenpay_cc_vault';

    /**
     * @var \Magento\Payment\Gateway\ConfigInterface
     */
    protected $config;

    /**
     * @var SessionManagerInterface
     */
    private $session;

    /**
     * ConfigProvider constructor.
     * @param Config $config
     */
    public function __construct(
        Config $config,
        SessionManagerInterface $session
    ) {
        $this->config = $config;
        $this->config->setMethodCode(self::CODE);
        $this->session = $session;
    }

    /**
     * Retrieve assoc array of checkout configuration
     *
     * @return array
     */
    public function getConfig()
    {
        $storeId = $this->session->getStoreId();
        $this->config->setMethodCode(self::CODE);
        $sandbox = $this->config->getValue(
            'sandbox'
        );

        return [
            'payment' => [
                self::CODE => [
                    'publicKey' => $this->config->getValue(
                        $sandbox ? self::PUBLIC_KEY_SANDBOX : self::PUBLIC_KEY
                    ),
                    'sandbox' => $sandbox,
                    'ccTypesMapper' => $this->config->getCcTypesMapper(),
                    'availableCardTypes' => $this->config->getAvailableCardTypes($storeId),
                    'ccVaultCode' => self::CC_VAULT_CODE
                ]
            ]
        ];
    }
}
