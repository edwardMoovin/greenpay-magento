<?php
namespace Greenpay\GreenpayPaymentGateway\Gateway\Response;

use Magento\Payment\Gateway\Data\PaymentDataObjectInterface;
use Magento\Payment\Gateway\Response\HandlerInterface;

/**
 * Class TxnIdHandler
 * @package Greenpay\GreenpayPaymentGateway\Gateway\Response
 */
class TxnIdHandler implements HandlerInterface
{
    /**
     * Store response data on payment
     *
     * @param array $handlingSubject
     * @param array $response
     * @return void
     */
    public function handle(array $handlingSubject, array $response)
    {
        //todo?
    }
}
