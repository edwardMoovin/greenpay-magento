<?php

namespace Greenpay\GreenpayPaymentGateway\Gateway\Response;

use Greenpay\GreenpayPaymentGateway\Gateway\Config\Config;
use Greenpay\GreenpayPaymentGateway\Gateway\SubjectReader;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Payment\Model\Method\Logger;

use Magento\Payment\Gateway\Response\HandlerInterface;
use Magento\Payment\Model\InfoInterface;
use Magento\Sales\Api\Data\OrderPaymentExtensionInterface;
use Magento\Sales\Api\Data\OrderPaymentExtensionInterfaceFactory;
use Magento\Payment\Gateway\Data\PaymentDataObjectInterface;

use Magento\Vault\Api\Data\PaymentTokenFactoryInterface;
use Magento\Vault\Api\Data\PaymentTokenInterface;

class GreenpayHandler implements HandlerInterface
{
    const TIMEOUT_CODE = 504;
    /**
     * @var Logger
     */
    private $logger;

    /**
     * @var PaymentTokenFactoryInterface
     */
    protected $paymentTokenFactory;

    /**
     * @var OrderPaymentExtensionInterfaceFactory
     */
    protected $paymentExtensionFactory;

    /**
     * @var SubjectReader
     */
    protected $subjectReader;

    /**
     * @var Config
     */
    protected $config;

    /**
     * @var Json
     */
    private $serializer;

    
    /**
     * VaultDetailsHandler constructor.
     *
     * @param PaymentTokenFactoryInterface $paymentTokenFactory
     * @param OrderPaymentExtensionInterfaceFactory $paymentExtensionFactory
     * @param Config $config
     * @param SubjectReader $subjectReader
     * @param Json|null $serializer
     * @throws \RuntimeException
     */
    public function __construct(
        Logger $logger,
        PaymentTokenFactoryInterface $paymentTokenFactory,
        OrderPaymentExtensionInterfaceFactory $paymentExtensionFactory,
        Config $config,
        SubjectReader $subjectReader,
        Json $serializer = null
    ) {
        $this->paymentTokenFactory = $paymentTokenFactory;
        $this->paymentExtensionFactory = $paymentExtensionFactory;
        $this->config = $config;
        $this->logger = $logger;
        $this->subjectReader = $subjectReader;
        $this->serializer = $serializer ?: ObjectManager::getInstance()->get(Json::class);
    }

    /**
     * @inheritdoc
     */
    public function handle(array $handlingSubject, array $response)
    {
        $this->logger->debug([ 'gp_handle' => $response ]);
        if (!isset($handlingSubject['payment'])
            || !$handlingSubject['payment'] instanceof PaymentDataObjectInterface
        ) {
            throw new \InvalidArgumentException('Payment data object should be provided');
        }

        /** @var PaymentDataObjectInterface $paymentDO */
        $paymentDO = $handlingSubject['payment'];

        $response = (Array)json_decode(json_encode($response), true);
        // Validate timeout
        if ( isset( $response['response'] ) ) {
            if ( $response['response'] == self::TIMEOUT_CODE ) {
                $payment = $paymentDO->getPayment();
                $payment->setAdditionalInformation('timeout', true);
            }
        }

        if ( isset( $response['result']['success'] ) ) {
            if ( (boolean) $response['result']['success'] ) {
                $payment = $paymentDO->getPayment();
                $payment->setAdditionalInformation('retrieval_ref_num', $response['result']['retrieval_ref_num']);
                $payment->setAdditionalInformation('authorization_id_resp', $response['result']['authorization_id_resp']);
                $payment->setAdditionalInformation('card_last4', $response['last4']);
                $payment->setAdditionalInformation('card_brand', $response['brand']);
        
                if ( isset( $response['tokenizeResp'] ) ) {
                    // add vault payment token entity to extension attributes
                    $paymentToken = $this->getVaultPaymentToken( $response['tokenizeResp'] );
                    if ( null !== $paymentToken ) {
                        $extensionAttributes = $this->getExtensionAttributes( $payment );
                        $extensionAttributes->setVaultPaymentToken( $paymentToken );
                    }
                }
            }
        }
    }

    /**
     * Get vault payment token entity
     *
     * @param array $transaction GP Transaction
     * @return PaymentTokenInterface|null
     */
    protected function getVaultPaymentToken( $transaction )
    {
        $paymentToken = null;

        // Check token existing in gateway response
        if ( isset( $transaction['result']['token'] ) ) {
            $exp_date = $this->getExpirationDate( $transaction );
            $paymentToken = $this->paymentTokenFactory->create( PaymentTokenFactoryInterface::TOKEN_TYPE_CREDIT_CARD );
            $paymentToken->setGatewayToken( $transaction['result']['token'] );
            $paymentToken->setExpiresAt( $exp_date['formatted_date'] );
            
            $paymentToken->setTokenDetails($this->convertDetailsToJSON([
                'type' => $this->getCreditCardType( $transaction['brand'] ),
                'maskedCC' => $transaction['result']['last_digits'],
                'expirationDate' => $exp_date['exp_month'] . '/' . $exp_date['exp_year'],
                'cardHolder' => $transaction['cardHolder']
            ]));
        }

        return $paymentToken;
    }

    /**
     * @param $transaction
     * @return array exp_month | exp_year | formatted_date
     */
    private function getExpirationDate( $transaction )
    {
        if ( ! is_array( $transaction ) && ! isset( $transaction['expiration_date'] ) && strlen( $transaction['expiration_date'] ) < 4 ) {
            return false;
        }

        $expiration_month = substr( $transaction['expiration_date'], 2, 4 );
        $expiration_year = '20' . substr( $transaction['expiration_date'], 0, 2 );
        
        $expDate = new \DateTime(
            $expiration_year
            . '-'
            . $expiration_month
            . '-'
            . '01'
            . ' '
            . '00:00:00',
            new \DateTimeZone('UTC')
        );
        $expDate->add(new \DateInterval('P1M'));

        return array(
            'exp_month' => $expiration_month,
            'exp_year' => $expiration_year,
            'formatted_date' => $expDate->format('Y-m-d 00:00:00')
        );
    }

    /**
     * Convert payment token details to JSON
     * @param array $details
     * @return string
     */
    private function convertDetailsToJSON( $details )
    {
        $json = $this->serializer->serialize($details);
        return $json ? $json : '{}';
    }

    /**
     * Get type of credit card mapped from Greenpay
     *
     * @param string $type
     * @return array
     */
    private function getCreditCardType( $type )
    {
        $replaced = str_replace(' ', '-', strtolower($type));
        $mapper = $this->config->getCcTypesMapper();

        return isset( $mapper[$replaced] ) ? $mapper[$replaced] : $replaced;
    }

    /**
     * Get payment extension attributes
     * @param InfoInterface $payment
     * @return OrderPaymentExtensionInterface
     */
    private function getExtensionAttributes( InfoInterface $payment )
    {
        $extensionAttributes = $payment->getExtensionAttributes();
        if ( null === $extensionAttributes ) {
            $extensionAttributes = $this->paymentExtensionFactory->create();
            $payment->setExtensionAttributes($extensionAttributes);
        }
        return $extensionAttributes;
    }
}
