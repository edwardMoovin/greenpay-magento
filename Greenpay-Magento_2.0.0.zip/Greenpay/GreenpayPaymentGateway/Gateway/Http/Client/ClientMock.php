<?php
namespace Greenpay\GreenpayPaymentGateway\Gateway\Http\Client;

use Magento\Payment\Gateway\Http\ClientInterface;
use Magento\Payment\Gateway\Http\TransferInterface;
use Magento\Payment\Model\Method\Logger;

use Magento\Framework\Module\ModuleListInterface;
use Greenpay\GreenpayPaymentGateway\Gateway\Config\Config;

use Magento\Customer\Model\Session;
use Greenpay\GreenpayPaymentGateway\Model\GreenpayBitacoraFactory;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * Class ClientMock
 * @package Greenpay\GreenpayPaymentGateway\Gateway\Http\Client
 */
class ClientMock implements ClientInterface
{
    /**
     * Greenpay Success Code
     */
    const SUCCESS = 200;
    const MODULE_KEY = 'Greenpay_GreenpayPaymentGateway';
    const MODULE_NAME = 'Magento Greenpay';

    /**
     * Greenpay Sandbox URLS
     */
    const SANDBOX_CHECKOUT_URL = 'https://sandbox-checkout.greenpay.me/kount';
    const SANDBOX_PAYMENT_URL = 'https://sandbox-merchant.greenpay.me';
    const SANDBOX_DELETE_TOKEN = 'https://sandbox-merchant.greenpay.me/deleteToken';

    /**
     * Greenpay Production URLS
     */
    const CHECKOUT_URL = 'https://checkout.greenpay.me/kount';
    const PAYMENT_URL = 'https://merchant.greenpay.me';
    const DELETE_TOKEN = 'https://merchant.greenpay.me/deleteToken';

    /**
     * @var Logger
     */
    private $logger;

    /**
     * @var \Magento\Framework\HTTP\Client\Curl
     */
    private $_curl;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    private $_storeManager;

    /**
     * @var \Magento\Sales\Model\Order
     */
    private $_orderRepository;
    
    /**
     * @var ModuleListInterface
     */
    protected $moduleList;

    /**
     * @var \Magento\Payment\Gateway\ConfigInterface
     */
    protected $config;
    
    /**
     * @var \Magento\Sales\Api\OrderRepositoryInterface
     */
    protected $orderRepository;

    /**
     * @var \Greenpay\GreenpayPaymentGateway\Model\GreenpayBitacoraFactory
     */
    protected $dataBitacora;

    /**
     * @var \Magento\Framework\Setup\SchemaSetupInterface
     */
    protected $setup;

    /**
     * ClientMock constructor.
     * @param Logger $logger
     * @param \Magento\Framework\HTTP\Client\Curl $curl
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Sales\Model\Order $orderRepository
     * @param ModuleListInterface $moduleList
     */
    public function __construct(
        Logger $logger,
        \Magento\Framework\HTTP\Client\Curl $curl,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Sales\Model\Order $orderRepository,
        ModuleListInterface $moduleList,
        Config $config,
        \Magento\Framework\Encryption\EncryptorInterface $encryptor,
        Session $customerSession,
        GreenpayBitacoraFactory $dataBitacora,
        SchemaSetupInterface $setup
        ) {
        $this->logger = $logger;
        $this->_curl = $curl;
        $this->_storeManager = $storeManager;
        $this->_orderRepository = $orderRepository;
        $this->moduleList = $moduleList;
        $this->config = $config;
        $this->config->setMethodCode('greenpay');
        $this->_encryptor = $encryptor;
        $this->debug = true;
        $this->customerSession = $customerSession;
        $this->dataBitacora = $dataBitacora;
        $this->setup = $setup;

        // Delete token
        $this->is_sandbox = (bool) ( $this->config->getValue('sandbox') && $this->config->getValue('sandbox') === '1' );
        $this->gp_secret = $this->_encryptor->decrypt( $this->config->getValue( $this->is_sandbox ? 'secret_sandbox' : 'secret' ) );
        $this->gp_merchant_id = $this->_encryptor->decrypt( $this->config->getValue( $this->is_sandbox ? 'merchant_id_sandbox' : 'merchant_id' ) );
        $this->gp_delete_token_url = $this->is_sandbox ? self::SANDBOX_DELETE_TOKEN : self::DELETE_TOKEN;

        // Bitácora
        $this->bitacora_data = array(
            'user_id' => $this->customerSession->getCustomerId(),
            'transaction_date' => date( 'Y-m-d H:i:s' ),
            'authcode' => '',
            'transactionid' => '',
            'error' => ''
        );
    }

    /**
     * @param TransferInterface $transferObject
     * @return array|bool
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function placeRequest(TransferInterface $transferObject)
    {
        $requestData = $transferObject->getBody();

        /**
         * Get payment order
         */
        $response = false;
        if ( $orderData = $this->getPaymentOrder($requestData) ) {
            if ( $this->debug ) {
                // Log before placeOrder on Magento    
                $this->logger->debug([ 'gp_paymentOrder' => $orderData ]);
            }

            if ( isset( $orderData['session'] ) && isset( $orderData['token'] ) ) {
                $response = $this->placeOrder($requestData, $orderData);
            }
        }
        
        // Check if table exists
        if ( $this->setup->getConnection()->isTableExists( 'greenpay_transactions' ) ) {
            // Bitácora
            $model = $this->dataBitacora->create();
            $model->addData( $this->bitacora_data );
            $model->save();
        } else {
            $this->logger->debug([ 'message' => 'No se encuentra tabla de bitácora', 'bitacora' => json_encode( $this->bitacora_data ) ]);
        }

        return $response;
    }

    /**
     * @param $requestData
     * @return bool|mixed|string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    private function getPaymentOrder($requestData)
    {
        $order_id = isset( $requestData['order_increment'] ) ? $requestData['order_increment'] : ( isset( $requestData['orderId'] ) ? $requestData['orderId'] : '' );

        $parameters = [
            'secret' => ($requestData['secret']) ?? '',
            'merchantId' => ($requestData['merchant_id']) ?? '',
            'terminal' => ($requestData['terminal']) ?? '',
            'amount' => (float)($requestData['amount']) ?? 0,
            'currency' => $this->_storeManager->getStore()->getBaseCurrencyCode(),
            'description' => ( !empty( $order_id ) ) ? 'Transaction order #' . $order_id : '',
            'orderReference' => $order_id
        ];
        
        // Bitácora
        $this->bitacora_data['amount'] = $parameters['amount'];
        $this->bitacora_data['order_id'] = $order_id;
        $this->bitacora_data['currency'] = $parameters['currency'];

        if ( isset( $requestData['additional'] ) ) {
            $parameters['additional'] = $requestData['additional'];
        }

        $url = ( $this->is_sandbox ) ? self::SANDBOX_PAYMENT_URL : self::PAYMENT_URL;

        $this->_curl->setHeaders( $this->getGreenpayHeaders() );
        $this->_curl->post( $url, json_encode( $parameters ) );

        if ( $response  = $this->_curl->getBody() ) {
            $response = (Array)json_decode( $response );
            $response['order_data'] = $parameters;
            $response['url'] = $url;
        }

        return is_array( $response ) ? $response : false;
    }

    /**
     * Process the order and save the transaction to DB
     * @param $requestData
     * @param $orderData
     * @return array|string
     */
    private function placeOrder($requestData, $orderData)
    {
        $url = ( $this->is_sandbox ) ? self::SANDBOX_CHECKOUT_URL : self::CHECKOUT_URL;
        
        $parameters = [
            'session' => ($orderData['session']) ?? '',
            'ld' => ($requestData['payment_method_nonce']['ld']) ?? '',
            'lk' => ($requestData['payment_method_nonce']['lk']) ?? ''
        ];

        $headers = $this->getGreenpayHeaders();
        $headers["Accept"] = "application/json";
        $headers["liszt-token"] = ( $orderData['token'] ) ?? '';

        $this->_curl->setHeaders( $headers );
        $this->_curl->post( $url, json_encode($parameters) );
        
        $log_response = [
            'url' => $url,
        ];

        $response = [
            'status' => '',
            'result' => ( object ) [],
            'errors' => ''
        ];

        // Validate timeout
        if ( intval( $this->_curl->getStatus() == 504 ) ) {
            $response['response'] = 504;
        } else {
            // Log on placeOrder
            $log_response['session'] = json_encode( $parameters );
            $log_response['headers'] = json_encode( $headers );
            $log_response['status'] = $this->_curl->getStatus();

            if ( $response = $this->_curl->getBody() ) {
                $response = (Array)json_decode($response);
                $log_response['place_order'] = json_encode( $response );
            }
        }

        // Bitácora
        $this->bitacora_data = array_merge( $this->bitacora_data, array(
            'authcode' => ( $response['authorization'] ) ?? '',
            'transactionid' => ( !empty( $response['result'] ) && isset( $response['result']->retrieval_ref_num ) ) ? $response['result']->retrieval_ref_num : '',
            'status' => ( $response['status'] ) ?? '404',
        ) );
        
        if ( isset( $response['errors'] ) && is_array( $response['errors'] ) && !empty( $response['errors'] ) ) {
            $this->bitacora_data['error'] = isset( $response['result']->resp_code ) ? json_encode( array( $response['result']->resp_code, $response['result']->reserved_private4 ) ) : json_encode( $response['errors'] );
        } else if ( isset( $response['error'] ) ) {
            // If it's an error with session
            $this->bitacora_data['error'] = $response['error'];
        }

        if ( $this->debug ) {
            $log_response['bitacora'] = $this->bitacora_data; 
            $this->logger->debug([ 'gp_placeOrder' => $log_response ]);
        }

        return $response;
    }

    /**
     * Process http request
     * @param array $data
    */
    protected function process(array $data) {}

    /**
     * Get request headers
     * @since 2.0.0
     * @return array Headers for Greenpay requests
     */
    private function getGreenpayHeaders()
    {
        return array(
            "Content-Type" => "application/json",
            "User-Agent" => implode( '/', array( self::MODULE_NAME, $this->getVersion() ) )
            
        );
    }

    /**
     * Get Module version
     * @since 2.0.0
     */
    public function getVersion()
    {
        return $this->moduleList->getOne( self::MODULE_KEY )['setup_version'];
    }

    /**
     * Delete payment from GP
     * @since 2.0.0
     * @param string $token 
     * @param string $request_id 
     * @return mixed Bool on error, GP response on success
     */
    public function deleteTokenFromGreenpay( $token = '', $request_id = '' ) 
    {
        $parameters = array(
            'secret' => $this->gp_secret,
            'merchantId' => $this->gp_merchant_id,
            'requestId' => $request_id,
        );

        if ( !empty( $token ) ) {
            $parameters['token'] = $token;

            $log_response = array(
                'url' => $this->gp_delete_token_url,
                'request' => $parameters
            );

            $this->_curl->setHeaders( $this->getGreenpayHeaders() );
            $this->_curl->post( $this->gp_delete_token_url, json_encode( $parameters ) );
    
            if ( $response  = $this->_curl->getBody() ) {
                $response = (Array)json_decode( $response );

                if ( $this->debug ) {
                    $log_response['response'] = $response;
                    $this->logger->debug([ 'gp_deleteToken' => $log_response ]);
                }

                return $response;
            }
        }

        return false;
    }
}
