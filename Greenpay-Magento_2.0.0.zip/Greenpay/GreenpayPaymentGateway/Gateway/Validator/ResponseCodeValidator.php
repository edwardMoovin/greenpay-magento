<?php
namespace Greenpay\GreenpayPaymentGateway\Gateway\Validator;

use Magento\Payment\Gateway\Validator\AbstractValidator;
use Magento\Payment\Gateway\Validator\ResultInterface;
use Greenpay\GreenpayPaymentGateway\Gateway\Http\Client\ClientMock;

/**
 * Class ResponseCodeValidator
 * @package Greenpay\GreenpayPaymentGateway\Gateway\Validator
 */
class ResponseCodeValidator extends AbstractValidator
{
    const RESULT_CODE = 'status';

    const ERROR_CODES = array('5', '01', '03', '05', '12', '13', '14', '19', '31', '51', '54', '55', '58', '63', '65', '78', '89', '91', '96', '201', '203', '205', '212', '219', '214', '251', '255', '303', '308', '278', '300', '400', '404', '410', '420', '262', '899', '993', '04', '41', '43', '204', '241', '996', '997', '500', '504', 'server_error', 'timeout');

    const TIMEOUT_CODES = array('500', '504', 'server_error', 'timeout');

    /**
     * Performs validation of result code
     *
     * @param array $validationSubject
     * @return ResultInterface
     */
    public function validate(array $validationSubject)
    {
        if (!isset($validationSubject['response']) || !is_array($validationSubject['response'])) {
            throw new \InvalidArgumentException('Response does not exist');
        }

        $response = $validationSubject['response'];
        if ($this->isSuccessfulTransaction($response)) {
            return $this->createResult(
                true,
                []
            );
        } else {
            $errors = $this->extractErrors($response);
            return $this->createResult(
                false,
                [], [ $errors[0] ]
            );
        }
    }

    /**
     * @param array $response
     * @return bool
     * 
     * @since 1.0.0
     * @version 2.0.1
     */
    private function isSuccessfulTransaction(array $response)
    {
        // If not in Timeout codes and not in Error codes
        if ( isset( $response[self::RESULT_CODE] ) && $response[self::RESULT_CODE] === 200 ) {
            return true;
        }
        return false;
    }

    /**
     * @param array $response
     * @return array Response error code
     * @since 1.0.0
     * @version 2.0.1
     */
    private function extractErrors(array $response)
    {
        $resp_code = 'UND2';
        $result = array();

        if ( isset( $response['result'] ) ) {
            $result = (array) $response['result'];
        }

        if ( isset( $result['resp_code'] ) ) {
            $resp_code = $result['resp_code'];
        } else if ( isset( $response['error'] ) ) {
            $resp_code = '404'; // SESSION NOT EXIST OR IT'S WRONG
        } else if ( isset( $response[self::RESULT_CODE] ) && in_array( $response[self::RESULT_CODE], self::TIMEOUT_CODES ) ) {
            $resp_code = 'server_error';
        }

        return [ $resp_code ];
    }
}
