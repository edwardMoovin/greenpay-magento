<?php
namespace Greenpay\GreenpayPaymentGateway\Gateway\Config;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Serialize\Serializer\Json;

/**
 * Class Config
 */
class Config extends \Magento\Payment\Gateway\Config\Config
{
    const KEY_CC_TYPES = 'cctypes';
    const KEY_CC_TYPES_GREENPAY_MAPPER = 'cctypes_greenpay_mapper';

    /**
     * @var \Magento\Framework\Serialize\Serializer\Json
     */
    private $serializer;

    /**
     * Greenpay config constructor
     *
     * @param ScopeConfigInterface $scopeConfig
     * @param null|string $methodCode
     * @param string $pathPattern
     * @param Json|null $serializer
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        $methodCode = null,
        $pathPattern = self::DEFAULT_PATH_PATTERN,
        Json $serializer = null
    ) {
        parent::__construct($scopeConfig, $methodCode, $pathPattern);
        $this->serializer = $serializer ?: \Magento\Framework\App\ObjectManager::getInstance()
            ->get(Json::class);
    }

    /**
     * Retrieve available credit card types
     *
     * @param int|null $storeId
     * @return array
     */
    public function getAvailableCardTypes($storeId = null)
    {
        $ccTypes = $this->getValue(self::KEY_CC_TYPES, $storeId);

        return !empty($ccTypes) ? explode(',', $ccTypes) : [];
    }

    /**
     * Retrieve mapper between Magento and Greenpay card types
     *
     * @return array
     */
    public function getCcTypesMapper()
    {
        // $result = json_decode(
        //     $this->getValue( self::KEY_CC_TYPES_GREENPAY_MAPPER ),
        //     true
        // );
        $result = array(
            'visa' => 'VI',
            'mastercard' => 'MC',
            'american-express' => 'AE',
            'amex' => 'AE',
            'discover' => 'DI',
            'jcb' => 'JCB',
        );

        return is_array( $result ) ? $result : [];
    }
}
