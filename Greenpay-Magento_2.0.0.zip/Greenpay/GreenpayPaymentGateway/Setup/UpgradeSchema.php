<?php

namespace Greenpay\GreenpayPaymentGateway\Setup;

use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\UpgradeSchemaInterface;

/**
 * Class InstallSchema
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        $connection = $setup->getConnection();
        $table_bitacora = $setup->getTable('greenpay_transactions'); // Bitácora

        if ( version_compare( $context->getVersion(), '1.0.1', '<' ) ) {
            $connection->addColumn(
                $setup->getTable('sales_order'),
                'greenpay_response',
                [
                    'type' => Table::TYPE_TEXT,
                    'nullable' => true,
                    'default' => null,
                    'comment' => 'Greenpay WebHook Response'
                ]
            );
        }

        if ( ! $connection->isTableExists( $table_bitacora ) ) {
            // Check for transactions table
            $new_table = $connection->newTable( $table_bitacora )
                ->addColumn(
                    'id',
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'identity' => true,
                        'unsigned' => true,
                        'nullable' => false,
                        'primary' => true
                    ]
                )
                ->addColumn(
                    'user_id',
                    Table::TYPE_SMALLINT,
                    null,
                    [
                        'nullable' => false,
                        'default' => 0
                    ]
                )
                ->addColumn(
                    'amount',
                    Table::TYPE_DECIMAL,
                    [10, 3],
                    [
                        'nullable' => false,
                        'default' => 0
                    ]
                )
                ->addColumn(
                    'order_id',
                    Table::TYPE_BIGINT,
                    20,
                    [
                        'nullable' => false,
                        'default' => 0
                    ]
                )
                ->addColumn(
                    'authcode',
                    Table::TYPE_TEXT,
                    25,
                    [
                        'nullable' => false,
                        'default' => 0
                    ]
                )
                ->addColumn(
                    'transactionid',
                    Table::TYPE_TEXT,
                    25,
                    [
                        'nullable' => false,
                        'default' => 0
                    ]
                )
                ->addColumn(
                    'transaction_date',
                    Table::TYPE_TIMESTAMP,
                    null,
                    [
                        'nullable' => false,
                        'default' => Table::TIMESTAMP_INIT
                    ]
                )
                ->addColumn(
                    'currency',
                    Table::TYPE_TEXT,
                    5,
                    [
                        'nullable' => true
                    ]
                )
                ->addColumn(
                    'status',
                    Table::TYPE_INTEGER,
                    4,
                    [
                        'nullable' => true
                    ]
                )
                ->addColumn(
                    'error',
                    Table::TYPE_TEXT,
                    255,
                    [
                        'nullable' => true
                    ]
                )
                ->setOption( 'charset', 'utf8' );

            $connection->createTable( $new_table );
        }

        $setup->endSetup();
    }
}
