var config = {
    'paths': {
        'aes-js': 'Greenpay_GreenpayPaymentGateway/js/greenpay/aes-js',
        'jsencrypt': 'Greenpay_GreenpayPaymentGateway/js/greenpay/jsencrypt'
    }
};
