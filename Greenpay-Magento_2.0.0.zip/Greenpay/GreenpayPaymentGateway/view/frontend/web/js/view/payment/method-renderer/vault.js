define(
    [
        'jquery',
        'Magento_Vault/js/view/payment/method-renderer/vault',
        'aes-js',

        'Magento_Checkout/js/view/payment/default',
        'Magento_Checkout/js/action/select-payment-method',
        'Magento_Checkout/js/checkout-data',

        'Magento_Ui/js/model/messageList',
        'Magento_Checkout/js/model/full-screen-loader',

        'jsencrypt'
    ],
    // 
    function ($, VaultComponent, aesjs, Greenpay, selectPaymentMethod, checkoutData, globalMessageList, fullScreenLoader) {
        'use strict';

        return VaultComponent.extend({
            defaults: {
                template: 'Magento_Vault/payment/form'
            },

            /**
             * @returns {exports.initObservable}
             */
            initObservable: function () {
                this._super()
                    .observe([]);

                return this;
            },

            /**
             * @returns
             */
            selectPaymentMethod: function () {
                selectPaymentMethod(
                    {
                        method: this.getId() // chosen payment id
                    }
                );
                checkoutData.setSelectedPaymentMethod( this.getId() );

                return true;
            },

            getCode: function () {
                return 'greenpay';
                // return this.code;
            },

            /**
             * Get data
             * @returns {Object}
             */
            getData: function () {
                var data = {
                    'method': this.getCode(),
                    'additional_data': {
                        'payment_method_nonce': window.paymentMethodNonce,
                        'public_hash': this.publicHash,
                        'is_vault': true
                    }
                };

                data['additional_data'] = _.extend(data['additional_data'], this.additionalData);

                return data;
            },

            /**
             * Get last 4 digits of card
             * @returns {String}
             */
            getMaskedCard: function () {
                return this.details.maskedCC;
            },

            /**
             * Get expiration date
             * @returns {String}
             */
            getExpirationDate: function () {
                return this.details.expirationDate;
            },

            /**
             * Get card type
             * @returns {String}
             */
            getCardType: function () {
                return this.details.type;
            },

            /**
             * AES Pairs
             * @returns {{s: *, k: Array}}
             */
            generateAESPairs: function () {
                var key = [];
                var iv;
                for (let k = 0; k < 16; k++) {
                    key.push(Math.floor(Math.random() * 255));
                }
                for (let k = 0; k < 16; k++) {
                    iv = Math.floor(Math.random() * 255);
                }

                return {
                    k: key,
                    s: iv
                };
            },

            /**
             * Pack ld, lk keys
             * @param obj
             * @param pair_
             * @returns {{ld: *, lk: string}}
             */
            pack: function (obj, pair_) {
                /**
                 * ld generation
                 */
                var pair = (pair_ !== undefined) ? pair_ : this.generateAESPairs();
                var textBytes = aesjs.utils.utf8.toBytes(JSON.stringify(obj));
                var aesCtr = new aesjs.ModeOfOperation.ctr(pair.k, new aesjs.Counter(pair.s));
                var encryptedBytes = aesCtr.encrypt(textBytes);
                var encryptedHex = aesjs.utils.hex.fromBytes(encryptedBytes);

                /**
                 * lk generation
                 */
                var encrypt = new JSEncrypt();
                encrypt.setPublicKey(window.checkoutConfig.payment['greenpay'].publicKey);
                var pairEncrypted = encrypt.encrypt(JSON.stringify(pair));

                return {
                    ld: encryptedHex,
                    lk: pairEncrypted
                };
            },

            /**
             * Set payment nonce
             * @param paymentMethodNonce
             */
            setPaymentMethodNonce: function (paymentMethodNonce) {
                window.paymentMethodNonce = JSON.stringify(paymentMethodNonce);
            },

            /**
             * Place order
             */
            placeOrder: function ( data, event ) {
                var self = this;
                
                if ( typeof window.gp_chosen_payment_method == 'undefined' || window.gp_chosen_payment_method != this.getId() ) {
                    self.getPaymentToken();
                } else {
                    return self._super();
                }
            },

            /**
             * Send request to get payment method nonce
             */
            getPaymentToken: function () {
                var id = jQuery('.payment-method._active input[type="radio"]').val();
                var token = ( typeof id != 'undefined' ) ? window.checkoutConfig.payment.vault[id].config.gateway_token : '';
                window.gp_chosen_payment_method = id;

                this.gDataCollectorInit( { token: token } );
            },

            /**
             * Data collector init
             */
            gDataCollectorInit: async function( data ) {
                let environment = parseInt(window.checkoutConfig.payment[this.getCode()]['sandbox']) ? 'sand' : 'prod',
                    collector = null,
                    self = this,
                    cipher = null;

                var gcollector = await GDataCollector.init(environment, null, function (result) {
                    collector = result;
                    collector.setupCallback({
                        // fires when collection has finished
                        'collect-end': function(params) {
                            if (params.MercSessId != undefined) {
                                $.extend(data, {
                                    kountSession: params.MercSessId 
                                });
            
                                var is_token = (data.token != undefined) ? true : false,
                                    saveCC = $('#greenpay_enable_vault').prop('checked');
                    
                                if ( is_token ) {
                                    // console.log( data );
                                    cipher = self.pack( data );

                                    // Append cipherd values to html.
                                    if (cipher.lk != undefined && cipher.ld != undefined) {
                                        self.setPaymentMethodNonce( $.extend(cipher, data) );
                                        self.placeOrder();
                                    }
                                }
                            }
                        },
                        // fires when collection has started. 
                        'collect-begin': function() {}
                    });
                    collector.collectData();
                });
            },

            /**
             * @param {String} type
             * @returns {Boolean}
             */
            getIcons: function (type) {
                return window.checkoutConfig.payment.ccform.icons.hasOwnProperty(type) ? window.checkoutConfig.payment.ccform.icons[type] : false;
            },

            /**
             * Returns state of place order button
             * 
             * @returns bool
             */
            isPlaceOrderActionAllowed: function() {
                return this.isActive();
            }
        });
    }
);