/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
/*browser:true*/
/*global define*/
define(
    [
        'jquery',
        'Magento_Payment/js/view/payment/cc-form',
        'Magento_Vault/js/view/payment/vault-enabler',
        'aes-js',
        'Magento_Checkout/js/model/quote',
        'Magento_Ui/js/model/messageList',
        'Magento_Payment/js/model/credit-card-validation/credit-card-number-validator',
        'Magento_Payment/js/model/credit-card-validation/expiration-date-validator',
        'mage/translate',
        'jsencrypt',
        
    ],
    // , aesjs, quote, globalMessageList, creditCardNumberValidator, expirationDateValidator
    function (
        $,
        Component,
        VaultEnabler,
        aesjs, quote, globalMessageList, creditCardNumberValidator, expirationDateValidator
    ) {
        'use strict';

        return Component.extend({
            defaults: {
                template: 'Greenpay_GreenpayPaymentGateway/payment/form',
                code: 'greenpay',
                paymentPayload: {
                    nonce: null
                },
                additionalData: {}
            },

            /**
             * Init component
             */
            initialize: function () {
                var self = this;

                self._super();
                this.vaultEnabler = new VaultEnabler();
                this.vaultEnabler.setPaymentCode(this.getVaultCode());
                self.validateForm();

                return self;
            },

            context: function () {
                return this;
            },

            getCode: function () {
                // return 'greenpay';
                return this.code;
            },

            isActive: function () {
                return true;
            },

            /**
             * Get data
             * @returns {Object}
             */
            getData: function () {
                var data = {
                    'method': this.getCode(),
                    'additional_data': {
                        'payment_method_nonce': window.paymentMethodNonce
                    }
                };

                data['additional_data'] = _.extend(data['additional_data'], this.additionalData);
                this.vaultEnabler.visitAdditionalData(data);

                return data;
            },

            /**
             * @returns {Boolean}
             */
            isVaultEnabled: function () {
                return this.vaultEnabler.isVaultEnabled();
            },

            /**
             * Returns vault code.
             *
             * @returns {String}
             */
            getVaultCode: function () {
                return window.checkoutConfig.payment[this.getCode()].ccVaultCode;
            },

            /**
             * Set payment nonce
             * @param paymentMethodNonce
             */
            setPaymentMethodNonce: function (paymentMethodNonce) {
                window.paymentMethodNonce = JSON.stringify(paymentMethodNonce);
            },

            /**
             * AES Pairs
             * @returns {{s: *, k: Array}}
             */
            generateAESPairs: function () {
                var key = [];
                var iv;
                for (let k = 0; k < 16; k++) {
                    key.push(Math.floor(Math.random() * 255));
                }
                for (let k = 0; k < 16; k++) {
                    iv = Math.floor(Math.random() * 255);
                }

                return {
                    k: key,
                    s: iv
                };
            },

            /**
             * Pack ld, lk keys
             * @param obj
             * @param pair_
             * @returns {{ld: *, lk: string}}
             */
            pack: function (obj, pair_) {
                /**
                 * ld generation
                 */
                var pair = (pair_ !== undefined) ? pair_ : this.generateAESPairs();
                var textBytes = aesjs.utils.utf8.toBytes(JSON.stringify(obj));
                var aesCtr = new aesjs.ModeOfOperation.ctr(pair.k, new aesjs.Counter(pair.s));
                var encryptedBytes = aesCtr.encrypt(textBytes);
                var encryptedHex = aesjs.utils.hex.fromBytes(encryptedBytes);

                /**
                 * lk generation
                 */
                var encrypt = new JSEncrypt();
                encrypt.setPublicKey(window.checkoutConfig.payment[this.getCode()].publicKey);
                var pairEncrypted = encrypt.encrypt(JSON.stringify(pair));

                return {
                    ld: encryptedHex,
                    lk: pairEncrypted
                };
            },

            /**
             * Generate random string
             * @param length
             * @returns {string}
             */
            makeid: function (length) {
                var result = '';
                var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
                var charactersLength = characters.length;
                for (var i = 0; i < length; i++) {
                    result += characters.charAt(Math.floor(Math.random() * charactersLength));
                }
                return result;
            },

            /**
             * Place order, generate payment nonce before.
             * @param data
             * @param event
             */
            placeOrder:  function (data, event) {
                var self = this;

                if ( data ) {
                    // console.log('data');
                    return self._super();
                }

                return self.placeOrder('parent');
            },

            placeOrderClick: function () {
                var self = this;

                /**
                 * Validate cc number
                 */
                if (!creditCardNumberValidator(this.creditCardNumber()).isValid) {
                    this._showErrors($.mage.__('Invalid credit card number.'));
                    return false;
                } else {
                    const cardInfo = creditCardNumberValidator(this.creditCardNumber()).card;
                    const allowedTypes = Object.values(window.checkoutConfig.payment['ccform']['availableTypes']['greenpay']);
                    let allow = false;

                    for (let i = 0, l = allowedTypes.length; i < l; i++) {
                        if (cardInfo.title === allowedTypes[i]) {
                            allow = true
                        }
                    }

                    if (!allow) {
                        this._showErrors($.mage.__('Invalid credit card type.'));
                        return false;
                    }
                }

                /**
                 * Validate expiration date
                 */
                if (!expirationDateValidator(this.creditCardExpMonth() + '/' + this.creditCardExpYear()).isValid) {
                    this._showErrors($.mage.__('Invalid expiration date.'));
                    return false;
                }

                /**
                 * Validate expiration date
                 */
                if (!Number.isInteger(parseInt(this.creditCardVerificationNumber()))) {
                    this._showErrors($.mage.__('Invalid verification number.'));
                    return false;
                }

                var cardData = {
                    "card": {
                        "cardHolder": quote.billingAddress().firstname + ' ' + quote.billingAddress().lastname,
                        "expirationDate": {
                            "month": parseInt(this.creditCardExpMonth()),
                            "year": Number(this.creditCardExpYear().slice(-2))
                        },
                        "cardNumber": self.formatCCNumber( this.creditCardNumber() ), // Sanitize cc number
                        "cvc": this.creditCardVerificationNumber()
                    }
                };

                self.gDataCollectorInit( cardData );
            },

            /**
             * Always enable Place Order button
             * @returns true
             */
            isPlaceOrderActionAllowed: function() {
                return this.isActive();
            },

            /**
             * Data collector init
             */
            gDataCollectorInit: async function( data ) {
                let environment = parseInt(window.checkoutConfig.payment[this.getCode()]['sandbox']) ? 'sand' : 'prod',
                    collector = null,
                    self = this,
                    cipher = null;

                var gcollector = await GDataCollector.init(environment, null, function (result) {
                    collector = result;
                    collector.setupCallback( {
                        // fires when collection has finished
                        'collect-end': function(params) {
                            if (params.MercSessId != undefined) {
                                $.extend(data, {
                                    kountSession: params.MercSessId 
                                });
                                
                                var is_token = (data.token != undefined) ? true : false,
                                    saveCC = $('#greenpay_enable_vault').prop('checked');
                    
                                if ( ! is_token ) {
                                    if ( saveCC ) {
                                        $.extend(data, {
                                            "tokenize": true
                                        });
                                    }
                    
                                    cipher = self.pack( data );
                                    // Append cipherd values to html.
                                    if (cipher.lk != undefined && cipher.ld != undefined) {
                                        self.setPaymentMethodNonce( cipher );
                                        self.placeOrder();
                                    }
                                } else {
                                    // console.log( data );
                                }
                            }
                        },
                        // fires when collection has started. 
                        'collect-begin': function() {}
                    } );
                    collector.collectData();
                });
            },

            /**
             * Validate CC number and CVC on keyup event
             */
            validateForm: function() {
                var self = this,
                    gaps = [],
                    cc_length = 16,
                    cc = '';

                $(document).on('keyup', '.payment-method-content #greenpay_cc_number', function ( e ) {
                    var validCard = creditCardNumberValidator(self.creditCardNumber()),
                        cc_input = $('#greenpay_cc_number').val();
                    cc = self.formatCCNumber( cc_input );
                    
                    // Check for valid card from Magento Payment
                    if ( validCard.card != null ) {
                        if ( typeof validCard.card.code != 'undefined' ) {
                            var cvc = validCard.card.code.size,
                                lengths = validCard.card.lengths;
                            
                            cc_length = lengths[0];
                            gaps = validCard.card.gaps;
                            gaps.push(cc_length);
                            
                            $('#greenpay_cc_cid').attr('maxlength', cvc);
                            self.formatCVC();
                        }
                    }

                    // Fix MC
                    // Formatting for CC proper length
                    if ( cc != '' && cc.length > cc_length && gaps != '' ) {
                        cc = cc.slice(0, cc_length);
                    }
                    
                    // Sanitizing and masking CC number
                    $('#greenpay_cc_number').val(self.validateCustomCC( cc, gaps ));
                    $('#greenpay_cc_number').trigger('change');
                });
                
                $(document).on('keyup', '.payment-method-content #greenpay_cc_cid', function () {
                    self.formatCVC();
                });
            },

            /**
             * Validates custom format for CC based on CC gaps returned by Magento
             * @param {string} cc 
             * @param {array} gaps 
             * @returns 
             */
            validateCustomCC: function( cc, gaps ) {
                var matches = cc.match(/\d{4,16}/g),
                    match = matches && matches[0] || '',
                    parts = [],
                    i = 0;

                $.each(gaps, function (index, value) {
                    if (match != '') {
                        var ccPart = match.substring(i, value);
                        if (ccPart != '') {
                            parts.push(ccPart);
                            i = value;
                        }
                    }
                });

                if (parts.length) {
                    return parts.join(' ')
                } else {
                    return cc;
                }
            },

            /**
             * Formatting CC number
             * @param {string} cc_number 
             * @returns Sanitized CC number without spaces
             */
            formatCCNumber: function( cc_number ) {
                return cc_number.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
            },

            /**
             * Format CVC length
             */
            formatCVC: function() {
                var value = $('#greenpay_cc_cid').val();
                var cvc = $('#greenpay_cc_cid').attr('maxlength');

                if ( typeof value != 'undefined' ) {
                    $('#greenpay_cc_cid').val( value.replace(/\D/g, '').slice(0, cvc) );
                }
            },

            /**
             * Show error messages
             * @param msg
             * @private
             */
            _showErrors: function (msg) {
                $(window).scrollTop(0);
                globalMessageList.addErrorMessage({
                    message: msg
                });
            }
        });
    }
);
